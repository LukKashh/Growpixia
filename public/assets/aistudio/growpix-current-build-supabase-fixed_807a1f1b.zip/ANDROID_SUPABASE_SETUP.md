# Android Supabase configuration

The native Android client reads its Supabase project URL and **public publishable key** from
`android/local.properties` at Gradle build time.

1. In the Android project folder, open `local.properties` (create it if it does not exist).
2. Keep any existing `sdk.dir=...` line.
3. Add the following properties, replacing the placeholder with the project's `sb_publishable_...` key from Supabase **Project Settings → API Keys**:

```properties
SUPABASE_URL=https://ydjynediqdmnosddwusw.supabase.co
SUPABASE_PUBLISHABLE_KEY=sb_publishable_REPLACE_WITH_YOUR_PROJECT_KEY
```

4. Sync Gradle, then build the Android app.

`local.properties` is machine-local and should not be committed to source control. The publishable key is designed for client applications. Never put `SUPABASE_SERVICE_ROLE_KEY`, an `sb_secret_...` key, or `AUTH_HMAC_SECRET` in Android, browser code, or any `VITE_` variable.

Android calls these Supabase Edge Function endpoints:
- `register-player`
- `login-player`
- `recover-player`

The Android configuration does not migrate Firebase data or establish that the complete app flow has been tested on a physical device. Edge Functions must already be deployed in the Supabase project, and their server-side secrets must be configured in Supabase.
